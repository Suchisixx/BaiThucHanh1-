package com.example.lab8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGoToSplash = findViewById(R.id.btn_go_to_splash);
        Button btnGoToProfile = findViewById(R.id.btn_go_to_profile);

        // Nút 1: Chuyển đến M000ActSplash
        btnGoToSplash.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, M000ActSplash.class);
            startActivity(intent);
        });

        // Nút 2: Chuyển đến M001ActProfile
        btnGoToProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, M001ActProfile.class);
            startActivity(intent);
        });
    }
}