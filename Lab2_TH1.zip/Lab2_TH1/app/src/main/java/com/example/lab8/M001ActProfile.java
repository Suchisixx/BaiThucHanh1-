package com.example.lab8;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class M001ActProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_profile);

        ImageView ivPhoneCall = findViewById(R.id.iv_phone_call);
        TextView tvPhoneNumber1 = findViewById(R.id.tv_phone_number_1);

        ivPhoneCall.setOnClickListener(v -> {
            String phoneNumber = tvPhoneNumber1.getText().toString();

            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + phoneNumber));
            startActivity(intent);
        });
    }
}
