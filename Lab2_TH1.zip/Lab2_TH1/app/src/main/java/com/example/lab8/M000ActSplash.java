package com.example.lab8;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.util.Random;

public class M000ActSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_splash);

        // 1. View từ layout
        LinearLayout layoutSplash = findViewById(R.id.layout_splash);
        ImageView ivAnimalIcon = findViewById(R.id.iv_animal_icon);

        // 2. Tạo danh sách tài nguyên (icon và màu)
        int[] icons = {
                R.drawable.ic_penguin,
                R.drawable.ic_lion,
                R.drawable.ic_cat
        };

        int[] colors = {
                R.color.bg_splash_blue,
                R.color.bg_splash_green,
                R.color.bg_splash_orange
        };

        // 3. Lấy số ngẫu nhiên
        Random rand = new Random();
        // Random một số từ 0 đến (số_lượng_icon - 1)
        int randomIndex = rand.nextInt(icons.length);

        // 4. Gán tài nguyên ngẫu nhiên cho View
        ivAnimalIcon.setImageResource(icons[randomIndex]);
        layoutSplash.setBackgroundColor(ContextCompat.getColor(this, colors[randomIndex]));
    }
}